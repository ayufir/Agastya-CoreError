const Bajaj = require("../model/Banks/BajajModel");
const HomeFirst = require("../model/Banks/homeFirstModel");
const Piramal = require("../model/Banks/piramalModel");
const HomeFirstTrench = require("../model/Banks/homeTrenchModel");
const ICICI_BANK = require("../model/Banks/IciciBankModel");
const Aditya = require("../model/Banks/AdityaBirlaModel");
const Manappuram = require("../model/Banks/manappuramModel");
const Sundaram = require("../model/Banks/sundaram.Model");
const Chola = require("../model/Banks/cholaModel");
const Agriwise = require("../model/Banks/agriwiseModel");
const HeroFinCorp = require("../model/Banks/HeroFinCopModel");
const PiramalNPA = require("../model/Banks/priamalFinanceModel");
const Samasta = require("../model/Banks/SamstaflnModel");
const Federal = require("../model/Banks/FedralModel");
const Profectus = require("../model/Banks/profectusModel");
const Protium = require("../model/Banks/ProtiumModel");
const IDFC = require("../model/Banks/idfcModal");
const BajajAmeriya = require("../model/Banks/BajajAmeriyaModel");
const DmiFinance = require("../model/Banks/DmiFinanceModel");
const ICICIHFC = require("../model/Banks/IcicihfcModel");
const BajajHousing = require("../model/Banks/BajajHousingModel")

const modelMap = {
  Homefirsttrench: HomeFirstTrench,
  Bajaj: Bajaj,
  BajajHousing: BajajHousing,
  Homefirst: HomeFirst,
  Piramal: Piramal,
  Icici: ICICI_BANK,
  Icicihfc: ICICIHFC,
  Aditya: Aditya,
  Manappuram: Manappuram,
};

const bankRegistry = [
  {
    key: "Homefirst",
    displayName: "Home First",
    route: "home-first",
    model: HomeFirst,
  },
  {
    key: "Homefirsttrench",
    displayName: "Home First Trench",
    route: "home-first-trench",
    model: HomeFirstTrench,
  },
  {
    key: "Icici",
    displayName: "ICICI Bank",
    route: "icici",
    model: ICICI_BANK,
  },
  { key: "Aditya", displayName: "Aditya Bank", route: "aditya", model: Aditya },
  {
    key: "Manappuram",
    displayName: "Manappuram Bank",
    route: "manappuram",
    model: Manappuram,
  },
  {
    key: "Piramal",
    displayName: "Piramal Bank",
    route: "piramal",
    model: Piramal,
  },
  {
    key: "Sundaram",
    displayName: "Sundaram Bank",
    route: "sundaram",
    model: Sundaram,
  },
  { key: "Chola", displayName: "Chola Bank", route: "chola", model: Chola },
  {
    key: "Agriwise",
    displayName: "Agriwise Bank",
    route: "agriwise",
    model: Agriwise,
  },
  {
    key: "Herofincorp",
    displayName: "Hero FinCorp Bank",
    route: "hero-fincorp",
    model: HeroFinCorp,
  },
  {
    key: "Piramalnpa",
    displayName: "Piramal NPA",
    route: "piramalnpa-form",
    model: PiramalNPA,
  },
  {
    key: "Samasta",
    displayName: "Samasta Bank",
    route: "samasta",
    model: Samasta,
  },
  {
    key: "Federal",
    displayName: "Federal Bank",
    route: "federal-bank",
    model: Federal,
  },
  {
    key: "Profectus",
    displayName: "Profectus Bank",
    route: "profectus",
    model: Profectus,
  },
  {
    key: "Protium",
    displayName: "Protium Bank",
    route: "protium",
    model: Protium,
  },
  { key: "Idfc", displayName: "IDFC Bank", route: "idfc-first-bank", model: IDFC },
  { key: "Bajaj", displayName: "Bajaj Bank", route: "bajaj", model: Bajaj },
  {
    key: "BajajHousing",
    displayName: "Bajaj Housing",
    route: "bajaj-housing",
    model: BajajHousing,
  },
  {
    key: "Bajajameriya",
    displayName: "Bajaj Ameriya Bank",
    route: "bajaj-ameriya-bank",
    model: BajajAmeriya,
  },
  {
    key: "Dmifinance",
    displayName: "DMI Finance",
    route: "dmi-finance",
    model: DmiFinance,
  },
  {
    key: "Icicihfc",
    displayName: "ICICI HFC",
    route: "icici-hfc",
    model: ICICIHFC,
  },
];

Object.defineProperty(modelMap, "bankRegistry", {
  value: bankRegistry,
  enumerable: false,
});

// Dynamically register all models from bankRegistry into modelMap
bankRegistry.forEach((entry) => {
  if (entry.key && entry.model) {
    const keysToAdd = [
      entry.key,
      entry.key.toLowerCase(),
      entry.displayName,
      entry.displayName?.toLowerCase(),
      entry.route,
      entry.route?.toLowerCase()
    ].filter(Boolean);

    keysToAdd.forEach((k) => {
      if (!modelMap[k]) {
        modelMap[k] = entry.model;
      }
    });
  }
});


// Dynamic injection of fields to all bank models to allow saving and retrieval
Object.values(modelMap).forEach((Model) => {
  if (Model && Model.schema) {
    if (!Model.schema.paths.atsDocuments) {
      Model.schema.add({ atsDocuments: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.siteVisitVideo) {
      Model.schema.add({ siteVisitVideo: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.gpsFiles) {
      Model.schema.add({ gpsFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.emailFiles) {
      Model.schema.add({ emailFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.fieldFormFiles) {
      Model.schema.add({ fieldFormFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.additionalFiles) {
      Model.schema.add({ additionalFiles: { type: [Object], default: [] } });
    }
  }
});

bankRegistry.forEach(({ model: Model }) => {
  if (Model && Model.schema) {
    if (!Model.schema.paths.atsDocuments) {
      Model.schema.add({ atsDocuments: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.siteVisitVideo) {
      Model.schema.add({ siteVisitVideo: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.gpsFiles) {
      Model.schema.add({ gpsFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.emailFiles) {
      Model.schema.add({ emailFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.fieldFormFiles) {
      Model.schema.add({ fieldFormFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.additionalFiles) {
      Model.schema.add({ additionalFiles: { type: [Object], default: [] } });
    }
    if (!Model.schema.paths.customCaseId) {
      Model.schema.add({ customCaseId: { type: String, default: "" } });
    }
    if (!Model.schema.paths.appIdNotes) {
      Model.schema.add({ appIdNotes: { type: String, default: "" } });
    }
    if (!Model.schema.paths.distance) {
      Model.schema.add({ distance: { type: String, default: "" } });
    }
    if (!Model.schema.paths.othersIfAny) {
      Model.schema.add({ othersIfAny: { type: String, default: "" } });
    }
    if (!Model.schema.paths.ratePerKm) {
      Model.schema.add({ ratePerKm: { type: Number, default: 3.50 } });
    }
    if (!Model.schema.paths.totalAllowance) {
      Model.schema.add({ totalAllowance: { type: Number, default: 0 } });
    }

    // Pre-save and pre-findOneAndUpdate hooks for customCaseId auto-generation
    Model.schema.pre("save", function (next) {
      if (!this.customCaseId) {
        const prefix = Model.modelName.slice(0, 3).toUpperCase();
        const rand = Math.floor(100000 + Math.random() * 900000);
        this.customCaseId = `${prefix}-${rand}`;
      }
      next();
    });

    Model.schema.pre("findOneAndUpdate", function (next) {
      const update = this.getUpdate();
      if (update) {
        let statusVal = "";
        let customIdVal = "";
        
        if (update.$set) {
          statusVal = update.$set.status || "";
          customIdVal = update.$set.customCaseId || "";
        } else {
          statusVal = update.status || "";
          customIdVal = update.customCaseId || "";
        }
        
        if ((statusVal.toLowerCase() === "generated" || statusVal.toLowerCase() === "pending") && !customIdVal) {
          const prefix = Model.modelName.slice(0, 3).toUpperCase();
          const rand = Math.floor(100000 + Math.random() * 900000);
          const generatedId = `${prefix}-${rand}`;
          
          if (update.$set) {
            update.$set.customCaseId = generatedId;
          } else {
            update.customCaseId = generatedId;
          }
        }
      }
      next();
    });

    // Add global post hooks for SuperAdmin notifications
    Model.schema.post("save", async function (doc, next) {
      if (doc) {
        try {
          const notifySuperAdmins = require("../utils/notifySuperAdmins");
          const bankName = doc.bankName || doc.bank || Model.modelName || "System";
          await notifySuperAdmins(doc._id, bankName, `Case ${doc.fileNumber || doc._id} was created/updated.`);
        } catch (e) {
          console.error("Hook save error:", e);
        }
      }
      next();
    });

    Model.schema.post("findOneAndUpdate", async function (doc, next) {
      if (doc) {
        try {
          const notifySuperAdmins = require("../utils/notifySuperAdmins");
          const bankName = doc.bankName || doc.bank || Model.modelName || "System";
          await notifySuperAdmins(doc._id, bankName, `Case ${doc.fileNumber || doc._id} was updated.`);
        } catch (e) {
          console.error("Hook findOneAndUpdate error:", e);
        }
      }
      next();
    });
  }
});

module.exports = modelMap;
