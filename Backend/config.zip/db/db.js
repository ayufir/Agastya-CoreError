const mongoose = require("mongoose");



const connectDb = async () => {
// console.log(process.env.MONGO_URI)
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected successfully");
  } catch (error) {
    console.log(error.message);
  }
};

module.exports = connectDb;
